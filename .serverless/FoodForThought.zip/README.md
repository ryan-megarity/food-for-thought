# Food For Thought Project

To deploy run 

serverless deploy

## Architecture Diagram:
https://app.cloudcraft.co/view/511050e4-1c7c-4483-9264-b069c26a6633?key=nQzfnBLpHCw9UyjpG5Mh0A
